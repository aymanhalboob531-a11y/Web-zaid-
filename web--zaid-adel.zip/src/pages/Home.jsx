import { Fragment } from "react";

export default function Home() {
  return (
    <Fragment>
      <div className="min-h-screen bg-[#2a2e35] text-white font-medium flex flex-col items-center justify-start py-12 px-4">
        {/* Hero Section */}
        <header className="max-w-5xl w-full text-center mb-12">
          <h1 className="text-5xl md:text-6xl font-extrabold mb-4">
            Welcome to Smis Platform
          </h1>
          <p className="text-lg md:text-xl text-gray-300 mb-8">
            Discover powerful tools designed to streamline your workflow.
          </p>
          <div className="flex justify-center space-x-4">
            <button className="bg-[#64ff00] text-black font-bold py-2 px-6 rounded-full hover:bg-[#55e600] transition duration-200">
              Login
            </button>
            <button className="border border-[#64ff00] text-[#64ff00] font-bold py-2 px-6 rounded-full hover:bg-[#64ff00] hover:text-black transition duration-200">
              Explore Features
            </button>
          </div>
        </header>

        {/* Features Grid */}
        <section className="max-w-5xl w-full grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
          <div className="bg-[#021f44] rounded-lg p-6 shadow-md flex flex-col">
            <h3 className="text-xl font-bold text-[#64ff00] mb-3">
              Secure Authentication
            </h3>
            <p className="text-sm font-medium text-gray-300 flex-grow">
              Multi‑factor authentication and role‑based access ensure that
              your data remains protected at all times.
            </p>
          </div>

          <div className="bg-[#021f44] rounded-lg p-6 shadow-md flex flex-col">
            <h3 className="text-xl font-bold text-[#64ff00] mb-3">
              Seamless Integration
            </h3>
            <p className="text-sm font-medium text-gray-300 flex-grow">
              Connect with popular services via OAuth and custom APIs to
              streamline workflows and unify data across platforms.
            </p>
          </div>

          <div className="bg-[#021f44] rounded-lg p-6 shadow-md flex flex-col">
            <h3 className="text-xl font-bold text-[#64ff00] mb-3">
              Analytics Dashboard
            </h3>
            <p className="text-sm font-medium text-gray-300 flex-grow">
              Gain real‑time insights into key metrics and performance
              indicators with intuitive visualizations.
            </p>
          </div>
        </section>
      </div>
    </Fragment>
  );
}