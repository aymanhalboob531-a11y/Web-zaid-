import React from 'react';

export default function Login() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-[#2a2e35] px-4">
      <div className="max-w-md w-full bg-[#021f44] rounded-xl shadow-xl p-8 space-y-6">
        <h2 className="text-3xl font-bold text-white text-center">
          Sign In
        </h2>
        <form className="space-y-5">
          <div>
            <label htmlFor="email" className="block text-sm font-medium text-white mb-1">
              Email address
            </label>
            <input
              id="email"
              type="email"
              autoComplete="email"
              required
              className="block w-full px-3 py-2 bg-transparent border border-gray-300 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-[#64ff00] focus:ring-1 focus:ring-[#64ff00]"
              placeholder="you@example.com"
            />
          </div>
          <div>
            <label htmlFor="password" className="block text-sm font-medium text-white mb-1">
              Password
            </label>
            <input
              id="password"
              type="password"
              autoComplete="current-password"
              required
              className="block w-full px-3 py-2 bg-transparent border border-gray-300 rounded-md text-white placeholder-gray-400 focus:outline-none focus:border-[#64ff00] focus:ring-1 focus:ring-[#64ff00]"
              placeholder="Enter your password"
            />
          </div>
          <button
            type="submit"
            className="w-full flex items-center justify-center gap-2 py-3 px-4 font-medium rounded-md bg-[#64ff00] text-[#021f44] hover:bg-[#5ae500] transition-colors duration-200"
          >
            🔒 Sign In
          </button>
        </form>
        <p className="text-sm text-center text-white">
          New to the platform? <a href="/signup" className="text-[#64ff00] hover:text-[#5ae500] font-medium">Create an account</a>
        </p>
      </div>
    </div>
  );
}