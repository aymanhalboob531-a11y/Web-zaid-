export default function ReportPage() {
  return (
    <div className="min-h-screen bg-gray-900 text-gray-100 font-sans">
      <header className="bg-[#021f44] text-white p-4 shadow-md">
        <div className="container mx-auto flex justify-between items-center">
          <h1 className="text-2xl font-bold tracking-tight">Report Generator</h1>
          <nav>
            <ul className="flex space-x-4">
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Home</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Reports</a></li>
              <li><a href="#" className="hover:text-yellow-400 transition-colors">Settings</a></li>
            </ul>
          </nav>
        </div>
      </header>

      <main className="container mx-auto p-6">
        <div className="bg-gray-800 rounded-lg shadow-lg p-6 mb-6">
          <h2 className="text-xl font-semibold text-yellow-400 mb-4">Generate New Report</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <label htmlFor="reportTitle" className="block text-sm font-medium mb-1">Report Title</label>
              <input
                type="text"
                id="reportTitle"
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
                placeholder="Enter report title"
              />
            </div>
            <div>
              <label htmlFor="reportType" className="block text-sm font-medium mb-1">Report Type</label>
              <select
                id="reportType"
                className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
              >
                <option value="financial">Financial</option>
                <option value="operational">Operational</option>
                <option value="performance">Performance</option>
              </select>
            </div>
          </div>
          <div className="mt-4">
            <label htmlFor="reportContent" className="block text-sm font-medium mb-1">Report Content</label>
            <textarea
              id="reportContent"
              rows="6"
              className="w-full p-2 bg-gray-700 border border-gray-600 rounded focus:outline-none focus:ring-2 focus:ring-yellow-400"
              placeholder="Enter report content here..."
            ></textarea>
          </div>
          <div className="mt-4 flex items-center">
            <input
              type="checkbox"
              id="bluetoothExport"
              className="h-4 w-4 text-yellow-400 focus:ring-yellow-400 border-gray-600 rounded"
            />
            <label htmlFor="bluetoothExport" className="ml-2 block text-sm text-gray-300">
              Enable Bluetooth Export
            </label>
          </div>
          <div className="mt-6 flex justify-end space-x-4">
            <button className="px-4 py-2 bg-gray-700 text-white rounded hover:bg-gray-600 transition-colors">
              Preview
            </button>
            <button className="px-4 py-2 bg-yellow-400 text-gray-900 rounded hover:bg-yellow-300 transition-colors font-medium">
              Generate PDF
            </button>
          </div>
        </div>

        <div className="bg-gray-800 rounded-lg shadow-lg p-6">
          <h2 className="text-xl font-semibold text-yellow-400 mb-4">Recent Reports</h2>
          <div className="overflow-x-auto">
            <table className="min-w-full bg-gray-700 rounded-lg overflow-hidden">
              <thead className="bg-gray-800">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Title</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Type</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Date</th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-300 uppercase tracking-wider">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-600">
                <tr className="hover:bg-gray-600 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">Q1 Financial Report</td>
                  <td className="px-6 py-4 whitespace-nowrap">Financial</td>
                  <td className="px-6 py-4 whitespace-nowrap">2023-01-15</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="text-yellow-400 hover:text-yellow-300 mr-2">View</button>
                    <button className="text-yellow-400 hover:text-yellow-300">Download</button>
                  </td>
                </tr>
                <tr className="hover:bg-gray-600 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">Operational Review</td>
                  <td className="px-6 py-4 whitespace-nowrap">Operational</td>
                  <td className="px-6 py-4 whitespace-nowrap">2023-02-20</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="text-yellow-400 hover:text-yellow-300 mr-2">View</button>
                    <button className="text-yellow-400 hover:text-yellow-300">Download</button>
                  </td>
                </tr>
                <tr className="hover:bg-gray-600 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap">Performance Metrics</td>
                  <td className="px-6 py-4 whitespace-nowrap">Performance</td>
                  <td className="px-6 py-4 whitespace-nowrap">2023-03-10</td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <button className="text-yellow-400 hover:text-yellow-300 mr-2">View</button>
                    <button className="text-yellow-400 hover:text-yellow-300">Download</button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </main>

      <footer className="bg-[#021f44] text-white p-4 mt-6">
        <div className="container mx-auto text-center">
          <p>&copy; 2023 Report Generator. All rights reserved.</p>
        </div>
      </footer>
    </div>
  );
}