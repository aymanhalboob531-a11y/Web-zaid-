```jsx
import React from "react";

export default function InspectionSummary() {
  const stats = {
    total: 1240,
    passed: 950,
    failed: 250,
    pending: 40,
  };

  const pivotData = [
    { region: "North", inspections: 300, passRate: 90 },
    { region: "South", inspections: 250, passRate: 85 },
    { region: "East", inspections: 300, pass